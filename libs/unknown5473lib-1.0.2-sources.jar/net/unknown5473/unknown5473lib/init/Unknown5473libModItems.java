/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.unknown5473.unknown5473lib.init;

import net.unknown5473.unknown5473lib.Unknown5473libMod;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;

import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;

import java.util.function.Function;

public class Unknown5473libModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(Unknown5473libMod.MODID);
	public static final DeferredItem<Item> U_ANIMATED_SPAWN_EGG = register("u_animated_spawn_egg", properties -> new SpawnEggItem(Unknown5473libModEntities.U_ANIMATED.get(), properties));

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}
}
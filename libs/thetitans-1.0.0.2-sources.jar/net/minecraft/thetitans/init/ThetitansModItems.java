/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.minecraft.thetitans.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;

import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.thetitans.ThetitansMod;

import java.util.function.Function;

public class ThetitansModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(ThetitansMod.MODID);
	public static final DeferredItem<Item> BASE_TITAN_SPAWN_EGG = register("base_titan_spawn_egg", properties -> new SpawnEggItem(ThetitansModEntities.BASE_TITAN.get(), properties));

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}
}
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.minecraft.thetitans.init;

import net.minecraft.thetitans.entity.extra.EntityItem;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.thetitans.entity.titan.BaseTitanEntity;
import net.minecraft.thetitans.ThetitansMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;
import net.unknown5473.unknown5473lib.entity.UAnimatedEntity;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class ThetitansModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(Registries.ENTITY_TYPE, ThetitansMod.MODID);
	public static final DeferredHolder<EntityType<?>, EntityType<BaseTitanEntity>> BASE_TITAN = register("base_titan",
			EntityType.Builder.<UAnimatedEntity>of(BaseTitanEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)

					.ridingOffset(-0.6f).sized(0.6f, 1.8f));

	// Start of user code block custom entities
	// End of user code block custom entities
	private static <T extends Entity> DeferredHolder<EntityType<?>, EntityType<T>> register(String registryname, EntityType.Builder<UAnimatedEntity> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(ResourceKey.create(Registries.ENTITY_TYPE, ResourceLocation.fromNamespaceAndPath(ThetitansMod.MODID, registryname))));
	}

	@SubscribeEvent
	public static void init(RegisterSpawnPlacementsEvent event) {
		BaseTitanEntity.init(event);
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(BASE_TITAN.get(), BaseTitanEntity.createAttributes().build());
	}
}
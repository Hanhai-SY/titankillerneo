package net.minecraft.thetitans.api;

public interface IAnimatedEntity {
    void onEventTrigged();

    void dyingGoalTick();

    void NewIdelGoals();

    void AnimatedStop();

    void IdelAnimatedStop();

    int catchPacketTick();

    void sendPacketTick(int paramInt);

    int sendPacketID();

    void setAnimatedID(int paramInt);

    void sendBasicTick(int paramInt);

    int catchBasicTick();

    void sendBasicID(int paramInt);

    int catchBasicID();
}
